const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get("/", (req, res) => {
    res.send(`
    <h1 style="border: 2px solid black; padding: 10px;"><span style="background-color:#ffd1a4;">Profile</h1>
    <div style="display: flex; gap: 40px; align-items: flex-start; margin-top: 20px;">

    <div>
    <img src="/profile.jpg" width="200"><br>
    <p style="font-weight: bold; margin-top: 10px;">이름 : 전병준</p>
    </div>

    <div style="font-size: 15px; line-height: 1.6;">
    <h2 style="border-left: 4px solid black; padding-left: 8px;"><span style="background-color:#ffd1a4;">자기소개</h2>
    <div style="border: 2px solid black; padding: 15px; border-radius: 5px;">
    <p>안녕하십니까 202208062 전병준입니다.</p>
    <p>저는 좋은 개발자가 되기 위해 열심히 공부하고있습니다.</p>
    <p>지금은 많이 부족하지만 졸업하고 반도체, 코딩 공부를 더 해서 좋은 엔지니어가 되고싶습니다 </p>
    </div>
  </div>
 </div>
    <hr style="border: 1px solid black; margin-top: 20px;">
    <div style="display: flex; gap: 40px; align-items: flex-start; margin-top: 20px;">
    <div style="font-size: 15px; line-height:1.6;">
    <h2 style="border-left: 4px solid black; padding-left: 8px;"><span style="background-color:#ffd1a4;">희망진로</h2>
    <div>
    <p style="font-weight: bold; margin-top: 10px;">&lt;반도체 엔지니어&gt;</p>
    <img src="/dream.jfif" width="300"><br>
    </div>
	
    </div>
    <div style="font-size: 15px; line-height:1.6;">
    <h2 style="border-left: 4px solid black; padding-left: 8px;"><span style="background-color:#ffd1a4;">취미</h2>
    <div>
    <p style="font-weight: bold; margin-top: 10px;">&lt;주식하기&gt;</p>
    <img src="/stock.jfif" width="300"><br>
    </div>

    </div>
    <div style="font-size: 15px; line-height:1.6;">
    <h2 style="border-left: 4px solid black; padding-left: 8px;"><span style="background-color:#ffd1a4;">좋아하는음식</h2>
    <div>
    <p style="font-weight: bold; margin-top: 10px;">&lt;소고기&gt;</p>
    <img src="/meat.jfif" width="300"><br>
    </div>
    
    </div>
    <div style="font-size: 15px; line-height:1.6;">
    <h2 style="border-left: 4px solid black; padding-left: 8px;"><span style="background-color:#ffd1a4;">공부중인 과목</h2>
    <div>
    <p style="font-weight: bold; margin-top: 10px;">&lt;토익&gt;</p>
    <img src="/toeic.png" width="280"><br>
    </div>
   </div>

  </div>
    <hr style="border: 1px solid black; margin-top: 20px;">
    <div style="margin-top: 20px;">
     <h2><span style="background-color:#ffd1a4;">MBTI</h2>
    <form method="POST" action="/greet">
      <input type="text" name="name" placeholder="이름"><br>
      <button type="submit">입력</button>
    </form>
    </div>
    <body style="background-color: #e0e0e0; margin: 0; padding: 20px;">
    `); //
    }); //

app.post("/greet", (req, res) => {
    const userName = req.body.name; 
    
    res.send(`
        <div style="padding: 20px; font-family: sans-serif;">
            <h1>@@ MBTI 분석 결과</h1>
            <p style="font-size: 18px;"><b>${userName}</b>님의 MBTI는 <span style="color: blue; font-weight: bold;">INFP</span> 입니다!</p>
            <br>
            <a href="/">← 자기소개 페이지로 돌아가기</a>
        </div>
    `);
});
    app.listen(PORT, () => {
    console.log(`서버 실행 중: http://localhost:${PORT}`);
});
